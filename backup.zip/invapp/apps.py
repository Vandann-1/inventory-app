from django.apps import AppConfig


class InvappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'invapp'
